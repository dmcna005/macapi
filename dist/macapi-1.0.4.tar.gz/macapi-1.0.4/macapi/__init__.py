#!/bin/python
"""Macapi init."""



from macapi.version import __version__
