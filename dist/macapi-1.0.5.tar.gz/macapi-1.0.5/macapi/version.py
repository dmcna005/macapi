#!/bin/python

"""macapi version."""

__version__ = '1.0.5'
